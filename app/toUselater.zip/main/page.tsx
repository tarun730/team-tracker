import React from 'react'
import Login from "../components/Login"
const App = () => {
  return (
    <>

      <div className="h-full w-full">
   this is main page
      </div>
    </>
  )
}




export default App