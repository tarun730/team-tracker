import React from 'react'
import Link from "next/link";
const dashboard = () => {
  return (
    <div>
      {/* <div id="navbar ">
             <Link href="/main/dashboard/alltask" className="uppercase mx-4">Dashboard</Link>
             <Link href="/main/dashboard/myprofile" className="uppercase mx-4">myprofile</Link>
             <Link href="/main/dashboard/tasks" className="uppercase mx-4">tasks</Link>
            </div> */}
      view all these links</div>
  )
}

export default dashboard