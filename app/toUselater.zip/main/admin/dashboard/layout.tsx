import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
// import { Nav } from "./components/Nav";

// import "./styles/globals.css";
import styles from "./styles/layout.module.css";

interface Props {
  readonly children: ReactNode;
}

export default function DashboardLayout({ children }: Props) {
  return (
          <section>
            <div id="navbar ">
             <Link href="/main/admin/dashboard/allemp_task" className="uppercase mx-4">Dashboard</Link>
             <Link href="/main/admin/dashboard/assign_tasks" className="uppercase mx-4">task assign</Link>
             <Link href="/main/admin/dashboard/detailed_emp_task" className="uppercase mx-4">detailed tasks</Link>
            </div>
             <div>{children}</div>
          </section>
  );
}
