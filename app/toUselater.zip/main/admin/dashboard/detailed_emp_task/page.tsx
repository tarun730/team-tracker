import React from 'react'

const Myprofile = () => {
  return (
    <div><h2>hey, tarun</h2>
    <h2>tarunmailgmail_com</h2></div>
  )
}

export default Myprofile