import Alltask from '@/app/components/Alltask'
import React from 'react'

const page = () => (
  <div>
    <Alltask />

  </div>
)

export default page