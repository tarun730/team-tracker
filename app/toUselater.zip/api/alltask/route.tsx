export function GET() {
    return new Response(JSON.stringify(
    [
        {
          "id": 1,
          "task": "Do this work",
          "total_hour": "3hr",
          "timeline": "3hr left"
        },
        {
          "id": 2,
          "task": "Finish project report",
          "total_hour": "5hr",
          "timeline": "5hr left"
        },
        {
          "id": 3,
          "task": "Prepare presentation slides",
          "total_hour": "2hr",
          "timeline": "2hr left"
        },
        {
          "id": 4,
          "task": "Review code",
          "total_hour": "4hr",
          "timeline": "4hr left"
        },
        {
          "id": 5,
          "task": "Attend team meeting",
          "total_hour": "1hr",
          "timeline": "1hr left"
        },
        {
          "id": 6,
          "task": "Test application",
          "total_hour": "6hr",
          "timeline": "6hr left"
        },
        {
          "id": 7,
          "task": "Design homepage",
          "total_hour": "7hr",
          "timeline": "7hr left"
        },
        {
          "id": 8,
          "task": "Write blog post",
          "total_hour": "3hr",
          "timeline": "3hr left"
        },
        {
          "id": 9,
          "task": "Fix bugs in the system",
          "total_hour": "8hr",
          "timeline": "8hr left"
        },
        {
          "id": 10,
          "task": "Deploy new feature",
          "total_hour": "10hr",
          "timeline": "10hr left"
        }
      ]
      
    ), { status: 200, headers: { "Content-Type": "application/json" } });
}
