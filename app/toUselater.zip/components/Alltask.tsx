"use client"
import React, { useEffect, useState } from 'react'
import Modal from './modal';




const data = [
  {
    id: 1,
    task: "do this work",
    total_hour: "3hr",
    timeline: "3hr left"
  },
  {
    id: 1,
    task: "do this work",
    total_hour: "3hr",
    timeline: "3hr left"
  },
  {
    id: 1,
    task: "do this work",
    total_hour: "3hr",
    timeline: "3hr left"
  },
]
interface Task {
  id: number;
  task: string;
  total_hour: string;
  timeline: string;
}

const Alltask = () => {
  // const [data, setdata] = useState<Task[]>(data);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleOpenModal = () => {
    setIsModalOpen(true);
  };
  // useEffect(() => {
  //   fetch("http://localhost:3000/api/alltask")
  //     .then((response) => response.json())  // Make sure to invoke .json() correctly
  //     .then((data) => {
  //       setdata(data)
  //     })
  //     .catch((error) => {
  //       console.error('Error fetching data:', error);
  //     });

  // },[])

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };
  return (
    <div className='m-10'>
      <table>
        <thead className='border p-4'>
          <tr>
            <th className='border p-4'>Sr. No.</th>
            <th className='border p-4'>Task Name</th>
            <th className='border p-4'>Total Hour</th>
            <th className='border p-4'> time Line</th>
            <th className='border p-4'> Action</th>
          </tr>
        </thead>
        <tbody>
          {
            data?.map((i, index) => (
              <tr className='border' key={index}>
                <td className='border p-4' >{i.id}</td>
                <td className='border p-4' >{i.task}</td>
                <td className='border p-4' >{i.total_hour}</td>
                <td className='border p-4' >{i.timeline}</td>
                <td className='border p-4' ><button onClick={handleOpenModal}>Open Modal</button></td>

              </tr>
            ))
          }

        </tbody>
      </table>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal}>
        <h2>Task Number: 02</h2>
        <p className='text-center'> Redesign the homepage of our company website</p>
        <p> <span>Given By</span> <span>Jane Cooper</span> </p>
        <div className='flex justify-between mt-6'>
          <button>Pause</button>
          <button>Completed</button>
        {/* <button onClick={handleCloseModal}>Close Modal</button> */}
        </div>
      </Modal>
    </div>
  )
}

export default Alltask;

