"use client"

import { useEffect } from 'react';
import styles from './Modal.module.css'; // You can style it using CSS Modules
type ModalProps = {
    isOpen: boolean;
    onClose: () => void; // Should be a function that returns nothing (void)
    children: React.ReactNode;
  };
const Modal: React.FC<ModalProps>  = ({ isOpen, onClose, children }) => {
//   useEffect(() => {
//     if (isOpen) {
//       document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
//     } else {
//       document.body.style.overflow = 'auto'; // Allow scrolling when modal is closed
//     }

//     return () => {
//       document.body.style.overflow = 'auto'; // Cleanup when component unmounts
//     };
//   }, [isOpen]);

  if (!isOpen) return null; // Don't render anything if the modal isn't open
  
  return (
    <div  className='bg-[#64748b82] fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full'  onClick={()=>onClose()}>
      <div className='flex justify-center max-h-full p-4 w-full' onClick={(e) => e.stopPropagation()}>
        <div className=' p-4 relative bg-white rounded-lg shadow dark:bg-gray-700'>
        <button  onClick={onClose}>
          &times; {/* Close button */}
        </button>
        {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;
