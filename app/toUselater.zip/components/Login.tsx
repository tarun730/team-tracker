"use client"
import { usePathname } from 'next/navigation'
import React from 'react'

const Login = () => {
    const pathname = usePathname()
    // console.log(pathname)
    return (
        <div className='flex flex-row items-center h-full w-full min-h-[100vh]'>
            <div className="primary_img w-[50%]"></div>
            <div className=" font-mono self-center ">
                <h3 className='w-full text-3xl font-3xl'>Welcome,{pathname=="/main/user/login"?"Team player! ":" Admin"} </h3>
                <p className='my-5'>Join us now to access your tasks from the inspiring team leader. Let's complete them with fun, enthusiasm, and meet all deadlines.</p>

                <label htmlFor="emailid"> Mail id:

                    <input className='border h-7' type="text" id="emailid" />
                    <input type="button" className='bg-gray-700 text-yellow-400 p-1 mx-2 rounded' value="submit" />
                </label>
            </div>
        </div>
    )
}

export default Login